#!/bin/bash

# Get the directory where the script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Change the current working directory to the script's directory
cd "$SCRIPT_DIR" || { echo "Failed to change directory to script's location. Exiting."; exit 1; }

# Default to 'Y' for automatic install (no user input required)
user_input="Y"

# Always proceed with the installation
echo "Proceeding with the installation..."

function compile_engine {
	cd engine/src
	rm -rf build # Remove build directory if it already exists
	mkdir build && cd build
	cmake ..
	make && make install
	cd "$SCRIPT_DIR"
}

ARCH=$(uname -m)

# Always install GTK 2 engine (defaulting to compilation if not x86_64 or i686)
if [ "$ARCH" = "x86_64" ] || [ "$ARCH" = "i686" ] || [ "$ARCH" = "i386" ]; then
    echo "Installing GTK 2 engine..."
    mkdir -p ~/.gtk-2.0/engines
	
    if [ "$ARCH" = "x86_64" ]; then
        cp engine/x86_64/libbluecurve.so ~/.gtk-2.0/engines
    else
        cp engine/i686/libbluecurve.so ~/.gtk-2.0/engines
    fi
else
    # If user is running something other than x86_64 or i686, they have to manually compile the theme
    echo "Compiling GTK 2 engine..."
    compile_engine
fi

# Copy icon set
echo "Installing icon set..."
mkdir -p ~/.icons
cp -r icons/* ~/.icons

# Copy themes
echo "Installing themes..."
mkdir -p ~/.themes
rm -rf ~/.themes/Bluecurve # Delete old theme files
rm -rf ~/.themes/Bluecurve-BerriesAndCream
rm -rf ~/.themes/Bluecurve-Classic-RH8
rm -rf ~/.themes/Bluecurve-Classic-RH9
rm -rf ~/.themes/Bluecurve-Gnome
rm -rf ~/.themes/Bluecurve-Grape
rm -rf ~/.themes/Bluecurve-Lime
rm -rf ~/.themes/Bluecurve-Slate
rm -rf ~/.themes/Bluecurve-Strawberry
rm -rf ~/.themes/Bluecurve-Tangerine
cp -r themes/* ~/.themes

# Always install the Luxi font family
echo "Installing the Luxi font family..."
mkdir -p ~/.local/share/fonts
cp fonts/*.ttf ~/.local/share/fonts

echo " "
echo "Bluecurve has been installed on your system!"
